from __future__ import annotations

import json
import os
import urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

BACKEND = os.getenv("RLDC_BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")
PORT = int(os.getenv("RLDC_OVERLAY_PORT", "8099"))
ROOT = Path(__file__).resolve().parent


def fetch_json(path: str, timeout: float = 4.0):
    with urllib.request.urlopen(BACKEND + path, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


class Handler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def send_json(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/health":
            return self.send_json({"ok": True, "backend": BACKEND, "dir": str(ROOT), "port": PORT})

        if path == "/overlay/api/live-state":
            try:
                return self.send_json(fetch_json("/api/rldc/safe/live-state", timeout=5))
            except Exception as e:
                return self.send_json({
                    "ok": False,
                    "backend": BACKEND,
                    "live_ready": False,
                    "mode": "--",
                    "allow_live_trading": False,
                    "updated_at": None,
                    "warning": "Overlay działa, ale backend safe API nie odpowiedział.",
                    "errors": [f"{type(e).__name__}: {e}"],
                    "positions": [],
                    "watchlist": [],
                    "summary": {
                        "active_position_count": 0,
                        "max_open_positions": None,
                        "total_value_eur": None,
                        "total_cost_eur": None,
                        "total_pnl_eur": None,
                        "total_pnl_pct": None,
                    },
                    "raw_control_ok": False,
                    "raw_analysis_ok": False,
                    "cache": {"state_age_sec": None, "analysis_age_sec": None},
                })

        return super().do_GET()

    def translate_path(self, path):
        clean = urlparse(path).path.lstrip("/")
        if not clean:
            clean = "index.html"
        return str((ROOT / clean).resolve())


if __name__ == "__main__":
    os.chdir(ROOT)
    print("Start RLdC overlay z PROJECT/live_overlay")
    print(f"Backend: {BACKEND}")
    print(f"OBS URL: http://127.0.0.1:{PORT}/index.html")
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
