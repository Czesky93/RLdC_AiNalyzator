#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
export RLDC_BACKEND_URL="${RLDC_BACKEND_URL:-http://127.0.0.1:8000}"
export RLDC_OVERLAY_PORT="${RLDC_OVERLAY_PORT:-8099}"
exec python3 serve_live.py
